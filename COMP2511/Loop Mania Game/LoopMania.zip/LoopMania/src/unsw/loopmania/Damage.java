package unsw.loopmania;

public interface Damage {
    
    public DamageClass dealDamage(Character character,BasicEnemy entity);
    
}
