package unsw.loopmania;

public class TreeStump extends Shield
{
    public TreeStump(int dropRate, String type, int purchasePrice,int x, int y)
    {
        super(dropRate,type,purchasePrice,x,y);
    }

}