package unsw.loopmania;

public class VampireCastle extends Spawner {
    public VampireCastle(int x, int y) {
        super(x,y,"Vampire Castle",3);
    }
}