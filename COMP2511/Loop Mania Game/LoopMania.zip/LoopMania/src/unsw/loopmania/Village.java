package unsw.loopmania;

public class Village extends Building {
    

    public Village(int x, int y) {
        super(x,y,"Village", 1);
        
    }

    
}