package unsw.loopmania;

public interface victory {
    public Boolean checkVictoryCondition(LoopManiaWorld w, Character c, int quantity);
}
