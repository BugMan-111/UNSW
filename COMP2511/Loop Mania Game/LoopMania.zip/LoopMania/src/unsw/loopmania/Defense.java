package unsw.loopmania;

public interface Defense {
    public void defense(DamageClass damage);
    public void specialEffect(DamageClass damage);
}
