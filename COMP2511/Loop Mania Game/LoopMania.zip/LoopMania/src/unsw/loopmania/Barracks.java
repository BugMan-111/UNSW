package unsw.loopmania;


public class Barracks extends Building {
    public Barracks(int x, int y) {
        super(x,y,"Barracks", 1);
    }
}