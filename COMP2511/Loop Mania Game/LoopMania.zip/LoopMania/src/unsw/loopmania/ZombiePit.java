package unsw.loopmania;

public class ZombiePit extends Spawner {
    public ZombiePit(int x , int y) {
        super(x,y,"Zombie Pit", 3);
    }
}