package unsw.loopmania;

import java.io.IOException;

// simple interface for lambda expression to switch a menu... no args required...
public interface MenuSwitcher {
    public void switchMenu() throws IOException;
}
