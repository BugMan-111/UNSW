package unsw.loopmania;

public class HerosCastle extends Building {
    public HerosCastle(int x, int y) {
        super(x,y,"Hero's Castle", 4);
    }
}