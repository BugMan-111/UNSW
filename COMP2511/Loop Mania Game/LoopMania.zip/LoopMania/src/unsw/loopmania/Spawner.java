package unsw.loopmania;

public abstract class Spawner extends Building {
    
    
    public Spawner(int x, int y,String type, int placement) {
        super(x, y,type, placement);
        
    }

    
}